import processing.core.PImage;

import java.util.List;
import java.util.Optional;

public class Ore implements Executable {

    //instance vars
    private String id;
    private Point position;
    private List<PImage> images;
    private int imageIndex;
    //private int resourceLimit;
    //private int resourceCount;
    private int actionPeriod;
    private int animationPeriod;

    //constructor
    public Ore(String id, Point position, List<PImage> images, int actionPeriod){
        this.id = id;
        this.position = position;
        this.images = images;
        this.actionPeriod = actionPeriod;
    }


    //methods
    public PImage getCurrentImage() {

        return (this).images.get((this).imageIndex);
    }

    public Point getPosition() {
        return position;
    }

    public void setPosition(Point newPosition){
        this.position = newPosition;
    }


    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore){
        scheduler.scheduleEvent(this,
                Functions.createActivityAction(this, world, imageStore),
                this.actionPeriod);
    }

    //corresponds with getAnimationPeriod
    public void nextImage() {
        this.imageIndex = (this.imageIndex + 1) % this.images.size();
    }

    public int getAnimationPeriod() {
        return this.animationPeriod;
    }


    //was executeOreActivity
    public void executeActivity(
            WorldModel world,
            ImageStore imageStore,
            EventScheduler scheduler)
    {
        Point pos = this.position;

        world.removeEntity(this);
        scheduler.unscheduleAllEvents(this);

        //FACTORY CLASS
        Animatable blob = FactoryClass.createOreBlob(this.id + Functions.BLOB_ID_SUFFIX, pos,
                this.actionPeriod / Functions.BLOB_PERIOD_SCALE,
                Functions.BLOB_ANIMATION_MIN + Functions.rand.nextInt(
                        Functions.BLOB_ANIMATION_MAX
                                - Functions.BLOB_ANIMATION_MIN),
                imageStore.getImageList(Functions.BLOB_KEY));

        world.addEntity(blob);
        //To fix this, make blob type executable
        blob.scheduleActions(scheduler, world, imageStore);
    }


}
