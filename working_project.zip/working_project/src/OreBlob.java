import processing.core.PImage;

import java.util.List;
import java.util.Optional;

public class OreBlob implements Movable {

    //instance vars
    private String id;
    private Point position;
    private List<PImage> images;
    private int imageIndex;
    //private int resourceLimit;
    //private int resourceCount;
    private int actionPeriod;
    private int animationPeriod;

    //constructor
    public OreBlob(String id, Point position, List<PImage> images, int actionPeriod, int animationPeriod){
        this.id = id;
        this.position = position;
        this.actionPeriod = actionPeriod;
        this.animationPeriod = animationPeriod;
        this.images = images;

    }


    //methods
    public PImage getCurrentImage() {

        return (this).images.get((this).imageIndex);
    }

    public Point getPosition() {
        return position;
    }

    public void setPosition(Point newPosition){
        this.position = newPosition;
    }


    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore){
        scheduler.scheduleEvent(this,
                Functions.createActivityAction(this, world, imageStore),
                this.actionPeriod);
        scheduler.scheduleEvent(this,
                Functions.createAnimationAction(this, 0),
                this.getAnimationPeriod());
    }

    //corresponds with getAnimationPeriod
    public void nextImage() {
        this.imageIndex = (this.imageIndex + 1) % this.images.size();
    }

    public int getAnimationPeriod() {
        return this.animationPeriod;
    }


    //was executeOreBlobActivity
    public void executeActivity(
            WorldModel world,
            ImageStore imageStore,
            EventScheduler scheduler)
    {
        Optional<Entity> blobTarget =
                world.findNearest(this.position, Vein.class);
        long nextPeriod = this.actionPeriod;

        if (blobTarget.isPresent()) {
            //changed from blobTarget.get().position; to blobTarget.get().getPosition();
            Point tgtPos = blobTarget.get().getPosition();

            //was moveToOreBlob
            if (this.moveTo(world, blobTarget.get(), scheduler)) {
                //FACTORY CLASS
                Animatable quake = FactoryClass.createQuake(tgtPos,
                        imageStore.getImageList(Functions.QUAKE_KEY));

                world.addEntity(quake);
                nextPeriod += this.actionPeriod;
                //TODO: make quake of type ?? executable/animatable
                quake.scheduleActions(scheduler, world, imageStore);
            }
        }

        scheduler.scheduleEvent(this,
                Functions.createActivityAction(this, world, imageStore),
                nextPeriod);
    }

    //entity
    //was moveToOreBlob
    public boolean moveTo(
            WorldModel world,
            Entity target,
            EventScheduler scheduler)
    {
        if (this.position.adjacent(target.getPosition())) {
            world.removeEntity(target);
            scheduler.unscheduleAllEvents(target);
            return true;
        }
        else {
            //was nextPositionOreBlob
            Point nextPos = this.nextPosition(world, target.getPosition());

            if (!this.position.equals(nextPos)) {
                Optional<Entity> occupant = world.getOccupant(nextPos);
                if (occupant.isPresent()) {
                    scheduler.unscheduleAllEvents(occupant.get());
                }

                world.moveEntity(this, nextPos);
            }
            return false;
        }
    }

    //entity
    //was nextPositionOreBlob
    public Point nextPosition(WorldModel world, Point destPos)
    {
        int horiz = Integer.signum(destPos.x - this.position.x);
        Point newPos = new Point(this.position.x + horiz, this.position.y);

        //Optional means may or may not contain null value
        Optional<Entity> occupant = world.getOccupant(newPos);

        //Check if occupant exists
        //Do i replace kind with class or getClass() ?
        if (horiz == 0 || (occupant.isPresent() && !(occupant.get().getClass()
                == Ore.class)))
        {
            int vert = Integer.signum(destPos.y - this.position.y);
            newPos = new Point(this.position.x, this.position.y + vert);
            occupant = world.getOccupant(newPos);

            if (vert == 0 || (occupant.isPresent() && !(occupant.get().getClass()
                    == Ore.class)))
            {
                newPos = this.position;
            }
        }

        return newPos;
    }


}
