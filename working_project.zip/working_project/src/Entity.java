//RECALL: WE NEED FACTORYCLASS. A new class we make called Factory.java
//A home for static create methods that we add back
//Not helpful for this project, but good practice.

//look at onstacle/blacksmith. every entity will need those methods put them in interface
//modify creates to return new types of entities
//Start by creating blacksmith/obstacle. These are the most basic so entity interface will for sure have the methods in these
//We will create more interfaces along the way, not just 2

//For some reasons, methods in interfaces shouldnt be declared public (abstract by default?)

import java.util.List;
import java.util.Optional;

import processing.core.PImage;

public interface Entity {
    PImage getCurrentImage();

    //Q: Blacksmith/Obstacle don't need to get position?
    //Look at MinerFull moveTo funct to see why getPosition() goes in entity
    Point getPosition();

    //Worldmodel calls entity.setPosition() so all entities need setPosition()
    void setPosition(Point newPosition);

    //Animation uses entity.nextImage()
    void nextImage();

    //Animation uses entity.getAnimationPeriod()
    int getAnimationPeriod();
}
