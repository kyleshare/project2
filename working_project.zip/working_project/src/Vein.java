//Veins are the rocks, which create the ore

import processing.core.PImage;

import java.util.List;
import java.util.Optional;

public class Vein implements Executable {

    //instance vars
    private String id;
    private Point position;
    private List<PImage> images;
    private int imageIndex;
    //private int resourceLimit;
    //private int resourceCount;
    private int actionPeriod;
    private int animationPeriod;

    //position, id, actionPeriod

    //constructor
    public Vein(String id, Point position, List<PImage> images, int actionPeriod){
        this.id = id;
        this.position = position;
        this.images = images;
        //this.imageIndex = imageIndex;
        this.actionPeriod = actionPeriod;

    }

    //methods
    public PImage getCurrentImage() {

        return (this).images.get((this).imageIndex);
    }

    public Point getPosition() {
        return position;
    }

    public void setPosition(Point newPosition){
        this.position = newPosition;
    }

    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore){
        scheduler.scheduleEvent(this,
                Functions.createActivityAction( this, world, imageStore),
                this.actionPeriod);
    }

    //corresponds with getAnimationPeriod
    public void nextImage() {
        this.imageIndex = (this.imageIndex + 1) % this.images.size();
    }

    public int getAnimationPeriod() {
        return this.animationPeriod;
    }


    //was executeVeinActivity
    public void executeActivity(
            WorldModel world,
            ImageStore imageStore,
            EventScheduler scheduler)
    {
        Optional<Point> openPt = world.findOpenAround(this.position);

        if (openPt.isPresent()) {
            //FACTORY CLASS
            Executable ore = FactoryClass.createOre(Functions.ORE_ID_PREFIX + this.id, openPt.get(),
                    Functions.ORE_CORRUPT_MIN + Functions.rand.nextInt(
                            Functions.ORE_CORRUPT_MAX - Functions.ORE_CORRUPT_MIN),
                    imageStore.getImageList(Functions.ORE_KEY));
            world.addEntity(ore);
            ore.scheduleActions(scheduler, world, imageStore);
        }

        scheduler.scheduleEvent(this,
                Functions.createActivityAction(this, world, imageStore),
                this.actionPeriod);
    }

}
