/* OLD ACTIONKIND

enum ActionKind
{
    ACTIVITY, ANIMATION
}
*/

//After refacting, Action,
public interface Action
{

    void executeAction(EventScheduler scheduler);


}
