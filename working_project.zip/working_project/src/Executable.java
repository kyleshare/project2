//Executable has all entity methods + scheduleActions
//Basically, it has methods MOST classes need (except blacksmith/obstacle)
public interface Executable extends Entity {

    //checks "kind" of entity, good hint it belongs in entity class
    //Not every class derived from Entity uses scheduleActions, so make new interface
    void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore);


    //All functions except blacksmith and obstacle use Execute___Activity
    void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler);
}

