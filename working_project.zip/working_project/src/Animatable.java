//Animatable has all of Executable methods (thus Entity methods too)
// and getAnimationPeriod/nextImage
//Has methods a few classes need (Minerfull, MinerNotFull, OreBlob, Quake)
public interface Animatable extends Executable {

    //corresponds with getAnimationPeriod
    void nextImage();

    int getAnimationPeriod();

}
