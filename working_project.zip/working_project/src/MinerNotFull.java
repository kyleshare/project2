//If miner disappears after getting ore, may be issue with transform

import processing.core.PImage;

import java.util.List;
import java.util.Optional;

public class MinerNotFull implements Movable {

    //instance vars
    private String id;
    private Point position;
    private List<PImage> images;
    private int imageIndex;
    private int resourceLimit;
    private int resourceCount; //Minerfull doesnt use this
    private int actionPeriod;
    private int animationPeriod;

    //constructor
    public MinerNotFull(String id, Point position, List<PImage> images, int imageIndex, int resourceLimit, int resourceCount, int actionPeriod) {
        this.id = id;
        this.position = position;
        this.images = images;
        this.imageIndex = imageIndex;
        this.resourceLimit = resourceLimit;
        this.resourceCount = resourceCount;
        this.actionPeriod = actionPeriod;
    }


    //methods
    public PImage getCurrentImage() {

        return (this).images.get((this).imageIndex);
    }

    public Point getPosition() {
        return position;
    }

    public void setPosition(Point newPosition){
        this.position = newPosition;
    }


    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore){
        scheduler.scheduleEvent(this,
                Functions.createActivityAction(this, world, imageStore),
                this.actionPeriod);
        scheduler.scheduleEvent(this,
                Functions.createAnimationAction(this, 0),
                this.getAnimationPeriod());
    }

    //corresponds with getAnimationPeriod
    public void nextImage() {
        this.imageIndex = (this.imageIndex + 1) % this.images.size();
    }

    public int getAnimationPeriod() {
        return this.animationPeriod;
    }


    //Was previously executeMinerNotFullActivity
    public void executeActivity(
            WorldModel world,
            ImageStore imageStore,
            EventScheduler scheduler)
    {
        Optional<Entity> notFullTarget =
                world.findNearest(this.position, Ore.class);

        //was moveToNotFull
        if (!notFullTarget.isPresent() || !this.moveTo(world,
                notFullTarget.get(),
                scheduler)
                || !this.transformNotFull(world, scheduler, imageStore))
        {
            scheduler.scheduleEvent(this,
                    Functions.createActivityAction(this, world, imageStore),
                    this.actionPeriod);
        }
    }

    //Change to moveTo, moveTo goes in MinerFull and MinerNotFull
    //was moveToNotFull
    //do i change entity to a minernotfull?
    public boolean moveTo(
            WorldModel world,
            Entity target,
            EventScheduler scheduler)
    {
        //Original syntax: if (adjacent(miner.position, target.position))
        //miner is object, position is object, adjacent is method
        if (this.position.adjacent(target.getPosition())) {
            this.resourceCount += 1;
            world.removeEntity(target);
            scheduler.unscheduleAllEvents(target);

            return true;
        }
        else {
            //was nextPositionMiner
            Point nextPos = this.nextPosition(world, target.getPosition());

            if (!this.position.equals(nextPos)) {
                Optional<Entity> occupant = world.getOccupant(nextPos);
                if (occupant.isPresent()) {
                    scheduler.unscheduleAllEvents(occupant.get());
                }

                world.moveEntity(this, nextPos);
            }
            return false;
        }
    }
    //entity
    //was transformnotfull
    //TODO: transformFull different return types than transformNotFull. Can't combine these into transform
    public boolean transformNotFull(
            WorldModel world,
            EventScheduler scheduler,
            ImageStore imageStore)
    {
        if (this.resourceCount >= this.resourceLimit) {
            //Use factory class instead of MinerFull.createMinerFull
            Executable miner = FactoryClass.createMinerFull(this.id, this.resourceLimit,
                    this.position, this.actionPeriod,
                    this.animationPeriod,
                    this.images);

            world.removeEntity(this);
            scheduler.unscheduleAllEvents(this);

            world.addEntity(miner);
            miner.scheduleActions(scheduler, world, imageStore);

            return true;
        }

        return false;
    }

    public Point nextPosition(WorldModel world, Point destPos)
    {
        int horiz = Integer.signum(destPos.x - this.position.x);
        Point newPos = new Point(this.position.x + horiz, this.position.y);

        if (horiz == 0 || world.isOccupied(newPos)) {
            int vert = Integer.signum(destPos.y - this.position.y);
            newPos = new Point(this.position.x, this.position.y + vert);

            if (vert == 0 || world.isOccupied(newPos)) {
                newPos = this.position;
            }
        }

        return newPos;
    }


    /* EXECUTE_ACTION IMPLEMENTATION ALREADY IN ACTIVITY
    public void executeAction(EventScheduler scheduler){
        //changed from: this.entity.executeActivity(this.world, this.imageStore, scheduler);
        this.entity.executeActivity(this.world, this.imageStore, scheduler)
        }

     */
}
