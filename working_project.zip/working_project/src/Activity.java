public class Activity implements Action {

    //instance vars in class private
    private Executable entity;
    private WorldModel world;
    private ImageStore imageStore;
    //private int repeatCount;

    //need constructor for class Activity
    public Activity(Executable entity, WorldModel world, ImageStore imageStore)
    {
        this.entity = entity;
        this.world = world;
        this.imageStore = imageStore;
    }


    public void executeAction(EventScheduler scheduler) {
        this.entity.executeActivity(this.world, this.imageStore, scheduler);
    }


}
