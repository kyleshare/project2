import processing.core.PImage;

import java.util.List;
import java.util.Optional;

public class Blacksmith implements Entity {

    //instance vars
    private String id; //ID IS IN CONSTRUCTOR BUT NOT USED. DO I NEED IT?
    private Point position;
    private List<PImage> images;
    private int imageIndex;
    //private int resourceLimit;
    //private int resourceCount;
    //private int actionPeriod;
    private int animationPeriod;



    //constructor
    public Blacksmith(String id, Point position, List<PImage> images){
        this.id = id;
        this.position = position;
        this.images = images;
    }



    public PImage getCurrentImage() {

        return (this).images.get((this).imageIndex);
    }

    public Point getPosition() {
        return this.position;
    }

    public void setPosition(Point newPosition){
        this.position = newPosition;
    }

    //corresponds with getAnimationPeriod
    public void nextImage() {
        this.imageIndex = (this.imageIndex + 1) % this.images.size();
    }

    public int getAnimationPeriod()
    {
        return this.animationPeriod;
    }

}
