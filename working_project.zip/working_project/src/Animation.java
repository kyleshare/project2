//"1 spot" where we need casting
//Only changing action, entity, and functions (unless compiler complains)
//
public class Animation implements Action {

    //instance vars in class private
    private Entity entity;
    //private WorldModel world;
    //private ImageStore imageStore;
    private int repeatCount;

    //need constructor for class Animation
    public Animation(Entity entity, int repeatCount)
    {
        this.entity = entity;
        this.repeatCount = repeatCount;
    }


    //action
    //rename "executeAction" move to Animation
    public void executeAction(EventScheduler scheduler)

    {
        //All entities need nextImage
        this.entity.nextImage();

        if (this.repeatCount != 1) {
            scheduler.scheduleEvent(this.entity,
                    Functions.createAnimationAction(this.entity,
                            Math.max(this.repeatCount - 1,
                                    0)),

                    this.entity.getAnimationPeriod());
        }
    }


}
