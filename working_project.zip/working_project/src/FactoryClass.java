import processing.core.PImage;

import java.util.List;

public class FactoryClass {

    public static Blacksmith createBlacksmith(
            String id, Point position, List<PImage> images)
    {
        //was Blacksmith(id, position, images, 0, 0, 0, 0)
        return new Blacksmith(id, position, images);
    }

    public static Movable createMinerFull(
            String id,
            int resourceLimit,
            Point position,
            int actionPeriod,
            int animationPeriod,
            List<PImage> images)
    {
        return new MinerFull(id, position, images,
                resourceLimit, actionPeriod,
                animationPeriod);
    }

    public static Movable createMinerNotFull(
            String id,
            int resourceLimit,
            Point position,
            int actionPeriod,
            int animationPeriod,
            List<PImage> images)
    {
        return new MinerNotFull(id, position, images,
                resourceLimit, 0, actionPeriod, animationPeriod);
    }

    public static Obstacle createObstacle(
            String id, Point position, List<PImage> images)
    {
        //changed from (id, position, images, 0, 0, 0, 0)
        return new Obstacle(id, position, images);
    }

    //changed "Ore" to "Executable"
    public static Executable createOre(
            String id, Point position, int actionPeriod, List<PImage> images)
    {
        //changed from (id, position, images, 0, 0, actionPeriod, 0)
        return new Ore(id, position, images, actionPeriod);
    }

    public static Movable createOreBlob(
            String id,
            Point position,
            int actionPeriod,
            int animationPeriod,
            List<PImage> images)
    {

        //THIS LINE SHOULD MATCH CONSTRUCTOR
        return new OreBlob(id, position, images, actionPeriod, animationPeriod);
    }

    public static Quake createQuake(
            Point position, List<PImage> images)
    {
        return new Quake(Functions.QUAKE_ID, position, images, Functions.QUAKE_ACTION_PERIOD, Functions.QUAKE_ANIMATION_PERIOD);
    }

    public static Executable createVein(String id, Point position, int actionPeriod, List<PImage> images)
    {
        //changed from Vein(id, position, images, 0, 0, actionPeriod, 0)
        return new Vein(id, position, images, actionPeriod);
    }









}
