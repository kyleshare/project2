import processing.core.PImage;

import java.util.List;
import java.util.Optional;

public class MinerFull implements Movable{
    //TODO: resolve PImage, resolve target.position, find other methods belonging here. Transform full passes params in weird order?


    //instance vars
    private String id;
    private Point position;
    private List<PImage> images;
    private int imageIndex;
    private int resourceLimit;
    //private int resourceCount; Doesnt use this but minernotfull does
    private int actionPeriod;
    private int animationPeriod;


    //constructor
    public MinerFull(String id, Point position, List<PImage> images, int resourceLimit, int actionPeriod, int animationPeriod){
        this.id = id;
        this.position = position;
        this.images = images;
        this.resourceLimit =  resourceLimit;
        this.actionPeriod = actionPeriod;
        this.animationPeriod = animationPeriod;


    }


    //methods
    public PImage getCurrentImage() {

        return (this).images.get((this).imageIndex);
    }

    public Point getPosition() {
        return position;
    }

    public void setPosition(Point newPosition){
        this.position = newPosition;
    }




    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore){
        scheduler.scheduleEvent(this,
                Functions.createActivityAction(this, world, imageStore),
                this.actionPeriod);
        scheduler.scheduleEvent(this,
                Functions.createAnimationAction(this, 0),
                this.getAnimationPeriod());
    }

    //corresponds with getAnimationPeriod
    public void nextImage() {
        this.imageIndex = (this.imageIndex + 1) % this.images.size();
    }

    public int getAnimationPeriod() {
        return this.animationPeriod;
    }



    //USES BLACKSMITH (only func that uses blacksmith)
    //goes in minerfull?
    //goes in executable?

    //was previously executeMinerFullActivity
    public void executeActivity(
            WorldModel world,
            ImageStore imageStore,
            EventScheduler scheduler)
    {
        //Try changing this to Optional<Executable>
        Optional<Entity> fullTarget =
                world.findNearest(this.position, Blacksmith.class);

        //was moveToFull
        if (fullTarget.isPresent() && this.moveTo( world,
                fullTarget.get(), scheduler))
        {
            this.transformFull(world, scheduler, imageStore);
        }
        else {
            scheduler.scheduleEvent(this,
                    Functions.createActivityAction(this, world, imageStore),
                    this.actionPeriod);
        }
    }

    //becomes moveTo, put in MinerFull/MinerNotFull?
    //was movetofull
    public boolean moveTo(
            WorldModel world,
            Entity target,
            EventScheduler scheduler)
    {
        //"this" was previously Entity miner
        //"target" is an Entity, need to be able to get the position of any Entity
        if (this.position.adjacent(target.getPosition())) {
            return true;
        }
        else {
            //was nextPositionMiner
            Point nextPos = this.nextPosition(world, target.getPosition());

            if (!this.position.equals(nextPos)) {
                Optional<Entity> occupant = world.getOccupant(nextPos);
                if (occupant.isPresent()) {
                    scheduler.unscheduleAllEvents(occupant.get());
                }

                world.moveEntity(this, nextPos);
            }
            return false;
        }
    }

    //Not in any interface
    public void transformFull(
            WorldModel world,
            EventScheduler scheduler,
            ImageStore imageStore)
    {

        Movable miner = FactoryClass.createMinerNotFull(this.id, this.resourceLimit,
                this.position, this.actionPeriod,
                this.animationPeriod,
                this.images);

        world.removeEntity(this);
        scheduler.unscheduleAllEvents(this);

        world.addEntity(miner);
        miner.scheduleActions(scheduler, world, imageStore);
    }


    public Point nextPosition(WorldModel world, Point destPos)
    {
        int horiz = Integer.signum(destPos.x - this.position.x);
        Point newPos = new Point(this.position.x + horiz, this.position.y);

        if (horiz == 0 || world.isOccupied(newPos)) {
            int vert = Integer.signum(destPos.y - this.position.y);
            newPos = new Point(this.position.x, this.position.y + vert);

            if (vert == 0 || world.isOccupied(newPos)) {
                newPos = this.position;
            }
        }

        return newPos;
    }




}
