//This is the most specific interface
//inherits all the way from Entity
//has methods that the fewest Classes need (MinerFull and MinerNotFull) & Possibly OreBlob? Oreblob has a moveTo but not a transform
public interface Movable extends Animatable {


    //becomes nextPosition, both MinerFull/Minernotfull?
    Point nextPosition(WorldModel world, Point destPos);


    //Note: OREBLOB uses moveto
    boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler);

}
